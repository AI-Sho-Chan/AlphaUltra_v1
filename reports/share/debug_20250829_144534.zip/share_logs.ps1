﻿Param([string]$tag=$(Get-Date -Format yyyyMMdd_HHmmss))
Set-StrictMode -Version Latest; $ErrorActionPreference="Stop"

$root=(Get-Location).Path
$checks="$root\reports\checks"; $share="$root\reports\share"
New-Item -ItemType Directory -Force $checks,$share | Out-Null

# 環境スナップショット
$envFile="$checks\env_$tag.txt"
$sec = if($env:SEC_USER_AGENT){"********"} else {"<empty>"}
$edn = if($env:EDINET_API_KEY) {"********"} else {"<empty>"}
$pyV = if(Test-Path .\.venv\Scripts\python.exe){ & .\.venv\Scripts\python.exe -V } else {"<none>"}
$pipV= if(Test-Path .\.venv\Scripts\pip.exe){    & .\.venv\Scripts\pip.exe -V    } else {"<none>"}
$pl  = if(Test-Path .\.venv\Scripts\pip.exe){ (& .\.venv\Scripts\pip.exe list) -join "`r`n" } else {"<none>"}
@"
root=$root
date=$(Get-Date -Format s)
git_origin=$(git remote get-url origin 2>$null)
python=$pyV
pip=$pipV
SEC_USER_AGENT=$sec
EDINET_API_KEY=$edn

### pip list
$pl
"@ | Set-Content -Encoding UTF8 $envFile

# 収集
$globs=@(
  "$checks\*.log","$checks\*summary*.csv","$checks\*status*.txt",
  "configs\*.yaml","scripts\*.py","scripts\*.ps1","utils\*.py",
  "data\raw\prices\*.parquet","data\proc\adj_prices\*.parquet",
  "data\proc\labels\*.parquet","data\proc\features_text\*.parquet"
)

$files=@()
foreach($g in $globs){
  $items = Get-ChildItem -Path $g -ErrorAction SilentlyContinue
  if($items){ $files += $items }
}
$files = $files | Select-Object -Expand FullName -Unique

$paths=@($envFile)
if($files){ $paths += $files | Where-Object { Test-Path $_ } }

$zip="reports\share\debug_$tag.zip"
Compress-Archive -LiteralPath $paths -DestinationPath $zip -Force
Write-Host "ZIP -> $zip"

# Git 共有（失敗時はZIPパスのみ表示）
try{
  git add $zip,$envFile | Out-Null
  git commit -m "chore(debug): logs pack $tag" | Out-Null
  git push | Out-Null
  $sha=(git rev-parse HEAD).Trim()
  $remote=(git remote get-url origin)
  if($remote -match 'github\.com[:/](.+?)/(.+?)(\.git)?$'){ $owner=$Matches[1]; $name=$Matches[2] }
  $zipRel = ($zip.Substring($root.Length+1)) -replace '\\','/'
  Write-Host ("COMMIT: https://github.com/{0}/{1}/commit/{2}" -f $owner,$name,$sha)
  Write-Host ("ZIP:    https://github.com/{0}/{1}/blob/{2}/{3}" -f $owner,$name,$sha,$zipRel)
}catch{
  Write-Warning "git push skipped. Share local ZIP: $zip"
}
