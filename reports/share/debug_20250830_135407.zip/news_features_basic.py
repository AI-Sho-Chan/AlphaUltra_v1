﻿import re, yaml, pandas as pd
from pathlib import Path
def ensure_dir(p: Path): p.mkdir(parents=True, exist_ok=True)

def load_news(root: Path):
    paths = list(root.rglob("*.parquet"))
    if not paths: 
        return pd.DataFrame(columns=["ts","title","ticker","source"])
    dfs=[]
    for p in paths:
        try:
            d=pd.read_parquet(p); d["__srcfile"]=str(p); dfs.append(d)
        except Exception: pass
    if not dfs: 
        return pd.DataFrame(columns=["ts","title","ticker","source"])
    df=pd.concat(dfs, ignore_index=True)
    if "title" not in df.columns:
        for k in ["headline","text","summary"]:
            if k in df.columns: df["title"]=df[k]; break
    df["title"]=df.get("title","").fillna("")
    if "ts" not in df.columns:
        for k in ["timestamp","ts","published","time","pub_ts","date"]:
            if k in df.columns: df["ts"]=pd.to_datetime(df[k], utc=True, errors="coerce"); break
    df["ts"]=pd.to_datetime(df.get("ts"), utc=True, errors="coerce")
    df=df.dropna(subset=["ts"])
    df["ticker"]=df.get("ticker").fillna("MARKET")
    return df

def aggregate_features(df_scores, windows, out_dir: Path, reports_dir: Path):
    # 空でも安全に動くように型を固定
    if "ts" not in df_scores.columns: df_scores["ts"]=pd.NaT
    df_scores["ts"]=pd.to_datetime(df_scores["ts"], utc=True, errors="coerce")
    for c in ["title","ticker","tone","pos","neg","unc","len"]:
        if c not in df_scores.columns: df_scores[c]=0 if c!="title" and c!="ticker" else ("" if c=="title" else "MARKET")
    df_scores=df_scores.dropna(subset=["ts"])
    if df_scores.empty:
        out_dir.mkdir(parents=True, exist_ok=True)
        reports_dir.mkdir(parents=True, exist_ok=True)
        (out_dir/"news_dict_features.parquet").write_bytes(b"")
        (reports_dir/"news_features_summary.csv").write_text("", encoding="utf-8")
        return
    df_scores["date"]=df_scores["ts"].dt.floor("D")
    base=df_scores.groupby(["ticker","date"]).agg(
        news_tone_mean_1d=("tone","mean"),
        news_tone_sum_1d=("tone","sum"),
        news_pos_1d=("pos","sum"),
        news_neg_1d=("neg","sum"),
        news_unc_1d=("unc","sum"),
        news_len_1d=("len","sum"),
        news_count_1d=("title","count")
    ).reset_index().sort_values(["ticker","date"])
    feats=[base]
    for w in windows:
        if w==1: continue
        def roll(g):
            g=g.set_index("date").sort_index()
            r=pd.DataFrame({
              f"news_tone_mean_{w}d": g["news_tone_mean_1d"].rolling(w,1).mean(),
              f"news_tone_sum_{w}d":  g["news_tone_sum_1d"].rolling(w,1).sum(),
              f"news_pos_{w}d":       g["news_pos_1d"].rolling(w,1).sum(),
              f"news_neg_{w}d":       g["news_neg_1d"].rolling(w,1).sum(),
              f"news_unc_{w}d":       g["news_unc_1d"].rolling(w,1).sum(),
              f"news_count_{w}d":     g["news_count_1d"].rolling(w,1).sum(),
            }).reset_index()
            r["ticker"]=g.index.name or g.reset_index().get("ticker",["MARKET"])[0]
            return r
        feats.append(base.groupby("ticker", group_keys=False).apply(roll))
    out=feats[0]
    for f in feats[1:]: out=out.merge(f, on=["ticker","date"], how="left")
    ensure_dir(out_dir); ensure_dir(reports_dir)
    out_path=out_dir/"news_dict_features.parquet"
    out.to_parquet(out_path, index=False)
    (reports_dir/"news_features_summary.csv").write_text(out.head(20).to_csv(index=False), encoding="utf-8")

if __name__=="__main__":
    import argparse, numpy as np
    ap=argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/text.yaml")
    args=ap.parse_args()
    cfg=yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    news_root=Path(cfg["paths"]["news_root"])
    out_dir=Path(cfg["paths"]["out_dir"])
    reports_dir=Path(cfg["paths"]["reports_dir"])
    windows=cfg.get("windows",[1,5,21])
    df=load_news(news_root)
    # 最小辞書スコアは0に固定（辞書無しでも動作させる）
    if df.empty:
        aggregate_features(pd.DataFrame(columns=["ts","ticker","title","tone","pos","neg","unc","len"]),
                           windows, out_dir, reports_dir)
    else:
        df["tone"]=0.0; df["pos"]=0; df["neg"]=0; df["unc"]=0; df["len"]=df["title"].astype(str).str.len()
        aggregate_features(df[["ts","ticker","title","tone","pos","neg","unc","len"]],
                           windows, out_dir, reports_dir)
