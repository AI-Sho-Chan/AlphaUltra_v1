﻿\
import yaml, pandas as pd, numpy as np
from pathlib import Path
from datetime import timezone

def guess_symbol(sec_code):
    if pd.isna(sec_code): return "JP_MARKET"
    try:
        s = str(int(sec_code)).zfill(4) + ".T"
    except Exception:
        s = str(sec_code).strip()
        if s and s.isdigit():
            s = s.zfill(4) + ".T"
        else:
            s = "JP_MARKET"
    return s

def main(cfg_path: str):
    cfg = yaml.safe_load(Path(cfg_path).read_text(encoding="utf-8"))
    csv_path = Path(cfg["paths"]["edinet_summary"])
    out_dir = Path(cfg["paths"]["out_dir"])
    reports = Path(cfg["paths"]["reports_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    reports.mkdir(parents=True, exist_ok=True)

    if not csv_path.exists():
        (reports/"edinet_features_status.txt").write_text("missing edinet_summary.csv", encoding="utf-8")
        return

    df = pd.read_csv(csv_path)
    if "submitDateTime" in df.columns:
        df["ts"] = pd.to_datetime(df["submitDateTime"], utc=True, errors="coerce")
    else:
        df["ts"] = pd.NaT
    df = df.dropna(subset=["ts"])
    df["date"] = df["ts"].dt.tz_convert("UTC").dt.floor("D")
    # symbol from secCode
    sym = df.get("secCode")
    df["ticker"] = sym.apply(guess_symbol) if sym is not None else "JP_MARKET"

    base = df.groupby(["ticker","date"]).agg(
        edinet_count_1d=("docID","count"),
    ).reset_index().sort_values(["ticker","date"])

    def roll(group, w):
        g = group.set_index("date").sort_index()
        return pd.DataFrame({
            f"edinet_count_{w}d": g["edinet_count_1d"].rolling(window=w, min_periods=1).sum()
        })

    feats = [base]
    for w in [5,21]:
        r = base.groupby("ticker", group_keys=False).apply(lambda g: roll(g, w)).reset_index()
        r = r.rename(columns={"level_1":"_tmp"}).drop(columns=["_tmp"], errors="ignore")
        feats.append(pd.concat([base[["ticker","date"]].reset_index(drop=True), r], axis=1))

    out = feats[0]
    for f in feats[1:]:
        out = pd.merge(out, f, on=["ticker","date"], how="left")

    # recency
    out = out.sort_values(["ticker","date"])
    out["days_since_edinet"] = out.groupby("ticker")["date"].diff().dt.days.fillna(9999).astype(int)

    out_path = out_dir / "edinet_doc_features.parquet"
    out.to_parquet(out_path, index=False)
    (reports/"edinet_features_summary.csv").write_text(out.head(30).to_csv(index=False), encoding="utf-8")

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/text.yaml")
    args = ap.parse_args()
    main(args.config)



