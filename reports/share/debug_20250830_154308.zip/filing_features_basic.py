﻿\
import yaml, pandas as pd, numpy as np
from pathlib import Path
from datetime import timezone
try:
    from utils.io_utils import ensure_dir
except Exception:
    def ensure_dir(p): Path(p).mkdir(parents=True, exist_ok=True)

def main(cfg_path: str):
    cfg = yaml.safe_load(Path(cfg_path).read_text(encoding="utf-8"))
    csv_path = Path(cfg["paths"]["filings_summary"])
    out_dir = Path(cfg["paths"]["out_dir"])
    reports = Path(cfg["paths"]["reports_dir"])
    weights = (cfg.get("weights") or {}).get("filing", {})
    out_dir.mkdir(parents=True, exist_ok=True)
    reports.mkdir(parents=True, exist_ok=True)

    if not csv_path.exists():
        (reports/"filing_features_status.txt").write_text("missing filings_summary.csv", encoding="utf-8")
        return

    df = pd.read_csv(csv_path)
    if "acceptanceDateTime" in df.columns:
        df["ts"] = pd.to_datetime(df["acceptanceDateTime"], utc=True, errors="coerce")
    elif "filedAt" in df.columns:
        df["ts"] = pd.to_datetime(df["filedAt"], utc=True, errors="coerce")
    else:
        df["ts"] = pd.NaT
    df = df.dropna(subset=["ts"])
    df["date"] = df["ts"].dt.tz_convert("UTC").dt.floor("D")
    sym = df["ticker"].fillna(df.get("symbol","MARKET") if "symbol" in df.columns else "MARKET")
    df["ticker"] = sym

    # event strength
    def w(form): 
        return float(weights.get(str(form), 0.5))
    df["event_w"] = df["form"].astype(str).map(lambda x: w(x))

    base = df.groupby(["ticker","date"]).agg(
        filing_count_1d=("form","count"),
        filing_event_strength_1d=("event_w","sum"),
        count_8K_1d=("form", lambda s: (s=="8-K").sum()),
        count_10Q_1d=("form", lambda s: (s=="10-Q").sum()),
        count_10K_1d=("form", lambda s: (s=="10-K").sum()),
    ).reset_index(drop=True)

    base = base.sort_values(["ticker","date"])

    def roll(group, w):
        g = group.set_index("date").sort_index()
        out = {}
        for col in ["filing_count_1d","filing_event_strength_1d","count_8K_1d","count_10Q_1d","count_10K_1d"]:
            out[f"{col[:-3]}_{w}d"] = g[col].rolling(window=w, min_periods=1).sum()
        return pd.DataFrame(out)

    feats = [base]
    for w in [5,21]:
        r = base.groupby("ticker", group_keys=False).apply(lambda g: roll(g, w)).reset_index(drop=True)
        r = r.rename(columns={"level_1":"_tmp"}).drop(columns=["_tmp"])
        feats.append(pd.concat([base[["ticker","date"]].reset_index(drop=True), r], axis=1))

    out = feats[0]
    for f in feats[1:]:
        out = pd.merge(out, f, on=["ticker","date"], how="left")

    # days since last filing
    out = out.sort_values(["ticker","date"])
    out["days_since_filing"] = out.groupby("ticker")["date"].diff().dt.days.fillna(9999).astype(int)

    out_path = out_dir / "filing_event_features.parquet"
    out.to_parquet(out_path, index=False)
    (reports/"filing_features_summary.csv").write_text(out.head(30).to_csv(index=False), encoding="utf-8")

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/text.yaml")
    args = ap.parse_args()
    main(args.config)




