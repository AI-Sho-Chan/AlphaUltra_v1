﻿import pandas as pd
from pathlib import Path

def main():
    ds_p = Path("data/proc/dataset/dataset_text_only.parquet")
    y_p  = Path("data/proc/labels/targets.parquet")
    out_p= Path("data/proc/dataset/dataset_final.parquet")
    out_p.parent.mkdir(parents=True, exist_ok=True)

    if not ds_p.exists() or not y_p.exists():
        print("missing inputs:", ds_p.exists(), y_p.exists()); return

    X = pd.read_parquet(ds_p)
    Y = pd.read_parquet(y_p)

    # 型と範囲を合わせる
    for df in (X, Y):
        df["date"] = pd.to_datetime(df["date"], errors="coerce")
    # ラベルに存在するtickerのみに絞る（MARKET系などを除外）
    keep = set(Y["ticker"].dropna().unique().tolist())
    X = X[X["ticker"].isin(keep)].copy()

    # ソート必須（merge_asofの前提）
    X = X.sort_values(["ticker","date"])
    Y = Y.sort_values(["ticker","date"])

    # 前方突合：イベント日→次のラベル日（最大10日先まで許容）
    df = pd.merge_asof(
        X, Y, on="date", by="ticker",
        direction="forward", tolerance=pd.Timedelta(days=10)
    )

    # ラベル欠損を除去
    label_cols = ["y_2x","rel_1M","rel_3M","rel_12M"]
    if not set(label_cols).issubset(df.columns):
        print("labels missing after merge"); return
    before = len(df)
    df = df.dropna(subset=label_cols)
    after = len(df)

    df.to_parquet(out_p, index=False)
    # サマリ
    feat_cols = [c for c in df.columns if c not in ["ticker","date"]+label_cols]
    print(f"final rows {after} / {before}, features {len(feat_cols)}, labels {len(label_cols)} -> {out_p}")
if __name__ == "__main__":
    main()
