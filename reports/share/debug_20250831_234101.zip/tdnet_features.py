# -*- coding: utf-8 -*-
import argparse, sys, json, re, math
from pathlib import Path
import pandas as pd
import yaml
from datetime import datetime, timedelta
from dateutil import parser as dparser
import pyarrow as pa
import pyarrow.parquet as pq

POS = ["上方修正","増配","自己株式取得","自社株買い","大型受注","受注","契約","承認","認可","発売","販売開始"]
NEG = ["下方修正","減配","公募増資","第三者割当","新株式発行","転換社債","希薄化","訴訟","不適切","不祥事","お詫び"]
NEU = ["業務提携","共同開発","設備投資","決算短信","決算","人事","社長交代","代表取締役の異動"]

DILUTIVE = ["公募増資","第三者割当","新株式発行","転換社債","希薄化"]

def read_cfg(p):
    with open(p, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def load_raw(tdnet_root: Path):
    recs = []
    for fp in tdnet_root.rglob("*.json"):
        try:
            with open(fp, "r", encoding="utf-8") as f:
                r = json.load(f)
                recs.append((fp, r))
        except Exception:
            continue
    return recs

def classify(title: str, body: str):
    txt = (title or "") + " " + (body or "")
    for w in POS:
        if w in txt:
            return ("POS", "Positive")
    for w in NEG:
        if w in txt:
            return ("NEG", "Negative")
    for w in NEU:
        if w in txt:
            return ("NEU", "Neutral")
    return ("UNK", "Neutral")

def is_dilutive(title: str, body: str):
    txt = (title or "") + " " + (body or "")
    return any(w in txt for w in DILUTIVE)

def novelty_score(df_code: pd.DataFrame):
    # simple title novelty: unseen title in past 365 days -> 1 else 0.5
    df_code = df_code.sort_values("published_at")
    seen = []
    scores = []
    for _, r in df_code.iterrows():
        cutoff = r["published_at"] - pd.Timedelta(days=365)
        # drop old
        seen = [s for s in seen if s[0] >= cutoff]
        th = (r["title"] or "").strip()
        h = hash(th)
        exists = any(h == s[1] for s in seen)
        scores.append(1.0 if not exists else 0.5)
        seen.append((r["published_at"], h))
    return pd.Series(scores, index=df_code.index)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()

    cfg = read_cfg(args.config)
    tdnet_root = Path(cfg["paths"]["tdnet_raw"])
    out_path = Path(cfg["paths"]["tdnet_features"])
    out_path.parent.mkdir(parents=True, exist_ok=True)

    recs = load_raw(tdnet_root)
    if not recs:
        print(f"[WARN] no tdnet json under {tdnet_root}", file=sys.stderr)
        return

    rows = []
    for fp, r in recs:
        code = str(r.get("code") or "").strip()
        title = r.get("title") or ""
        body = r.get("body") or ""
        ts = r.get("published_at_jst")
        try:
            dt = dparser.parse(ts)
        except Exception:
            dt = datetime.utcfromtimestamp(fp.stat().st_mtime)
        evt, pol = classify(title, body)
        dil = is_dilutive(title, body)
        rows.append({
            "code": code,
            "ticker": f"{code}.T" if code else None,
            "published_at": pd.Timestamp(dt),
            "date": pd.Timestamp(dt).normalize(),
            "title": title,
            "event_type": evt,
            "polarity": pol,
            "is_dilutive": bool(dil),
            "title_len": len(title)
        })
    df = pd.DataFrame(rows)
    # novelty per code
    df["novelty"] = (
        df.groupby("code", group_keys=False).apply(novelty_score).astype(float)
        if not df.empty else 0.0
    )
    # strength heuristic: presence of amount figure → 0.6 else 0.3 (placeholder)
    has_amount = df["title"].str.contains(r"\d+[億万BKMk%％]", regex=True, na=False)
    df["strength"] = has_amount.map({True:0.6, False:0.3}).astype(float)

    # gate
    prm = cfg.get("params", {})
    a = float(prm.get("alpha_strength", 0.6))
    b = float(prm.get("beta_novelty", 0.4))
    clip_min = float(prm.get("clip_min", 0.5))
    clip_max = float(prm.get("clip_max", 2.0))

    sign = df["polarity"].map({"Positive":1.0,"Neutral":0.0,"Negative":-1.0}).fillna(0.0)
    sign = sign - df["is_dilutive"].astype(float)  # dilutive penalty
    raw = 1.0 + a*df["strength"]*sign + b*df["novelty"]
    df["gate"] = raw.clip(clip_min, clip_max)

    cols = ["ticker","date","event_type","polarity","is_dilutive","strength","novelty","gate","title_len"]
    df_out = df[cols].sort_values(["ticker","date","event_type","title_len"])
    table = pa.Table.from_pandas(df_out, preserve_index=False)
    pq.write_table(table, out_path)
    print(f"[INFO] tdnet features saved: {out_path} rows={len(df_out)} cols={len(df_out.columns)}")

if __name__ == "__main__":
    main()
