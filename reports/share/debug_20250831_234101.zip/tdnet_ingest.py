# -*- coding: utf-8 -*-
import argparse, sys, json, hashlib
from pathlib import Path
import pandas as pd
import yaml
from datetime import datetime, timezone
from dateutil import parser as dparser

def read_cfg(p):
    with open(p, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def ensure_dir(p: Path):
    p.parent.mkdir(parents=True, exist_ok=True)

def normalize_row(row):
    # column synonyms
    def pick(row, keys):
        for k in keys:
            if k in row and pd.notna(row[k]):
                return str(row[k]).strip()
        return None
    code = pick(row, ["code","銘柄コード","証券コード","コード"])
    title = pick(row, ["title","表題","件名","タイトル","見出し"])
    url_pdf = pick(row, ["url_pdf","PDF","PDFリンク","pdf","PDFURL"])
    url_detail = pick(row, ["url_detail","URL","リンク","詳細URL"])
    body = pick(row, ["body","本文","内容","text"])
    published = pick(row, ["published_at","開示日時","公開日時","日時","date","time"])

    if not code or not published:
        return None

    # parse timestamp in JST if tz-naive
    try:
        dt = dparser.parse(published)
    except Exception:
        return None
    if dt.tzinfo is None:
        # assume JST if naive
        try:
            # JST+09:00
            dt = dt.replace(tzinfo=timezone.utc).astimezone(timezone.utc)  # store UTC for file name
        except Exception:
            dt = dt
    else:
        dt = dt.astimezone(timezone.utc)
    published_at_jst = dt.isoformat()

    return {
        "code": str(int(float(code))) if str(code).isdigit() else str(code).strip(),
        "title": title or "",
        "published_at_jst": published_at_jst,
        "url_pdf": url_pdf,
        "url_detail": url_detail,
        "body": body
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--input", help="CSV/TSV/JSON file or directory of files (Kabutan exports). If omitted, uses tdnet_inbox from config.")
    args = ap.parse_args()

    cfg = read_cfg(args.config)
    inbox = Path(args.input) if args.input else Path(cfg["paths"]["tdnet_inbox"])
    out_root = Path(cfg["paths"]["tdnet_raw"])
    logs_dir = Path(cfg["paths"].get("logs_dir", "reports/checks"))
    logs_dir.mkdir(parents=True, exist_ok=True)

    # collect files
    files = []
    if inbox.is_dir():
        for ext in ("*.csv","*.tsv","*.json","*.CSV","*.TSV","*.JSON"):
            files += list(inbox.rglob(ext))
    elif inbox.exists():
        files = [inbox]
    else:
        print(f"[WARN] inbox not found: {inbox}", file=sys.stderr)

    total = 0
    for fp in files:
        try:
            if fp.suffix.lower()==".json":
                df = pd.read_json(fp, dtype=str)
            else:
                # flexible CSV
                df = pd.read_csv(fp, dtype=str, sep=None, engine="python", encoding="utf-8-sig")
        except Exception:
            try:
                df = pd.read_csv(fp, dtype=str, sep=None, engine="python", encoding="cp932")
            except Exception as e:
                print(f"[WARN] read fail {fp}: {e}", file=sys.stderr)
                continue
        for _, r in df.fillna("").to_dict(orient="records"):
            rec = normalize_row(r)
            if not rec: 
                continue
            # path: YYYY/MM/DD/<code>_<hash>.json
            try:
                dt = dparser.parse(rec["published_at_jst"])
            except Exception:
                dt = datetime.utcnow().replace(tzinfo=timezone.utc)
            ymd = dt.strftime("%Y/%m/%d")
            key_src = f'{rec["code"]}|{rec["title"]}|{rec["published_at_jst"]}'
            hid = hashlib.sha1(key_src.encode("utf-8")).hexdigest()[:12]
            out_dir = out_root / ymd
            out_dir.mkdir(parents=True, exist_ok=True)
            out = out_dir / f'{rec["code"]}_{hid}.json'
            with open(out, "w", encoding="utf-8") as f:
                json.dump(rec, f, ensure_ascii=False)
            total += 1
    print(f"[INFO] tdnet ingest done. records={total} out_root={out_root}")
    if total==0:
        print("[WARN] no records created. Provide Kabutan exports to tdnet_inbox.", file=sys.stderr)

if __name__ == "__main__":
    main()
