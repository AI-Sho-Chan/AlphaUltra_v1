﻿import re, pathlib
targets=[
    pathlib.Path("tools/tdnet_kabutan_crawl_range.py"),
    pathlib.Path("tools/tdnet_kabutan_fetch_html.py"),
    pathlib.Path("tools/tdnet_kabutan_enrich_day.py"),
]
for p in targets:
    if not p.exists(): 
        print(f"skip: {p}"); 
        continue
    b = p.read_bytes()
    # まずSJISで試す→失敗ならUTF-8(ignore)
    try:
        s = b.decode("cp932")
    except Exception:
        s = b.decode("utf-8","ignore")
    # 文字化けした三連引用（"""...""" or '''...'''）を潰す
    s = re.sub(r'(?s)""".*?"""','"""doc"""', s)
    s = re.sub(r"(?s)'''.*?'''","'''doc'''", s)
    # 制御文字は空白に
    s = re.sub(r'[\x00-\x08\x0b-\x1f]',' ', s)
    p.write_text(s, encoding="utf-8")
    print(f"fixed: {p}")
print("done")
